package com.canadore.abin_benny_A00192794

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView

class DetailActivity : AppCompatActivity() {
    private lateinit var habitListView: ListView
    private lateinit var addButton: Button
    private val habits = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        habitListView = findViewById(R.id.habitListView)
        addButton = findViewById(R.id.addHabitButton)

        // Set up the ListView with a simple adapter
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, habits)
        habitListView.adapter = adapter

        addButton.setOnClickListener {
            val intent = Intent(this, AddUpdateHabitActivity::class.java)
            startActivityForResult(intent, REQUEST_CODE_ADD_HABIT)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_ADD_HABIT && resultCode == RESULT_OK) {
            data?.let {
                val newHabit = it.getStringExtra(EXTRA_HABIT)
                val time = it.getStringExtra(EXTRA_TIME)
                val day = it.getStringExtra(EXTRA_DAY)
                newHabit?.let { habit ->
                    // Add new habit to the list and update the adapter
                    habits.add("$habit at $time on $day")
                    (habitListView.adapter as ArrayAdapter<*>).notifyDataSetChanged()
                }
            }
        }
    }

    companion object {
        const val REQUEST_CODE_ADD_HABIT = 1
        const val EXTRA_HABIT = "EXTRA_HABIT"
        const val EXTRA_TIME = "EXTRA_TIME"
        const val EXTRA_DAY = "EXTRA_DAY"
    }
}
